# Reproducibility status

The FAME repository distinguishes three levels of reproducibility evidence.

## Level A — Auditability: complete

The repository contains the curated numerical artifacts supporting the manuscript:
temporal splits, frozen parameters, DOC calibration outputs, future operational results,
bootstrap analyses, robustness checks, and leakage/freeze audits.

These files permit direct verification of the quantitative claims made in the paper.

## Level B — Portable execution structure: complete

The six public notebooks have been refactored to:

- locate the repository root automatically;
- use documented external input locations;
- avoid author-machine absolute paths;
- write fresh outputs under `reproduced/`;
- keep archived paper evidence under `results/`;
- support explicit environment-variable overrides.

Static Python syntax checks pass for all notebook code cells.

## Level C — Independent clean-clone rerun: pending

A complete end-to-end rerun still requires the exact external source datasets:

- the fantasy-football analytical dataset;
- the compiled 2015--2025 TransnetBW load/forecast file;
- RTS-GMLC generator data (retrievable automatically from the official repository).

Once those files are available in the documented locations, the recommended verification is:

```bash
python scripts/validate_external_data.py
```

run all six notebooks in the documented order, then execute:

```bash
python scripts/compare_reproduced_results.py
```

The comparison script checks reproduced CSV artifacts against the archived paper evidence
using exact text matching and tight floating-point tolerances.

## Publication wording

Until Level C is completed, the README and manuscript should describe the repository as
providing **code and materials to audit and reproduce the reported analyses**, rather than
claiming that a clean-clone rerun has already been independently verified.
