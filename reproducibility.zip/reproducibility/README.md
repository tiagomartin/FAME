# Reproducibility guide

The repository is designed around the chronological protocol used in the paper:

`development -> DOC calibration -> parameter freeze -> future evaluation`

## Fantasy football

1. Run `code/fantasy_football/FAME_fantasy_football_primary.ipynb`.
2. Verify temporal folds and frozen predictive settings in `results/fantasy_football/model_selection/`.
3. Verify DOC calibration and frozen weights in `results/fantasy_football/calibration/`.
4. Reproduce the primary 2025 evaluation using `results/fantasy_football/evaluation/`.
5. Reproduce robustness analyses from `results/fantasy_football/robustness/`.
6. Check leakage and freeze audits in `results/fantasy_football/audit/`.
7. Run the H1 and H2 temporal-replication notebooks.

## Energy

1. Run `code/energy/FAME_energy_temporal_replication.ipynb`.
2. Check temporal split definitions under `data/energy/splits/`.
3. Verify frozen parameters and temporal summaries under `results/energy/temporal_replications/`.
4. Reproduce the operational robustness grid under `results/energy/robustness/`.
5. Run `code/energy/FAME_energy_scientific_synthesis.ipynb` for paper-level summaries.

## Important

Retrospective utility surfaces, ablation analyses, and local sensitivity analyses are diagnostic. They are not used to replace the representation frozen before the evaluation period.
