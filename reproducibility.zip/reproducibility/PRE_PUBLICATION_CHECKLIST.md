# Pre-publication checklist

- [ ] Create public repository `https://github.com/tiagomartin/FAME`
- [ ] Verify author names and ORCID identifiers in `CITATION.cff`
- [ ] Add exact software dependency versions (`requirements.txt` or `environment.yml`)
- [ ] Verify licenses/terms for every external dataset
- [ ] Add source URLs and acquisition instructions to `data/README.md`
- [ ] Confirm that no credentials, tokens, private paths, or personal data are present in notebooks
- [ ] Clear unnecessary notebook outputs if they contain machine-specific paths or large binary output
- [ ] Test notebooks from a clean environment
- [ ] Confirm manuscript numbers against `artifact_manifest.csv`
- [ ] Add repository URL to Data Availability and Code Availability statements
- [ ] Create GitHub release `v1.0.0` corresponding to the submitted/accepted manuscript
- [ ] Optionally archive the release in Zenodo and add the DOI to `CITATION.cff`

- [ ] Resolve the Energy synthesis notebook's expected input path versus curated `results/energy/`
- [ ] Test CBC discovery using `FAME_CBC_EXE` or system PATH
- [ ] Decide whether the Cartola analytical dataset can legally be redistributed
- [ ] Add exact acquisition/reconstruction instructions for TransnetBW and RTS-GMLC inputs

- [x] Remove the remaining local Windows path from `input_data_audit.csv`
- [x] Document the external Cartola FC, TransnetBW, and RTS-GMLC data dependencies
- [x] Add a portable RTS-GMLC retrieval helper
- [x] Add an external-input validation script
- [ ] Verify the exact legal/terms basis for redistributing the compiled TransnetBW dataset
- [ ] Decide whether to redistribute any Cartola FC analytical data or keep source-only reconstruction
- [ ] Generate and commit a schema report from the exact final TransnetBW input file

- [x] Refactor all six public notebooks to repository-relative paths
- [x] Separate archived paper artifacts (`results/`) from fresh reproduction outputs (`reproduced/`)
- [x] Add environment-variable overrides for all external inputs and CBC
- [x] Add clean-clone execution order
- [ ] Execute every notebook from a fresh clone with the exact external datasets
- [ ] Compare fresh outputs against archived results and record checksums/tolerances

- [x] Add automated comparison script for archived vs freshly reproduced results
- [x] Document three reproducibility evidence levels
- [x] Add manuscript-associated GitHub release procedure
- [ ] Run `scripts/compare_reproduced_results.py` after the clean-clone reproduction
- [ ] Commit the resulting `reproduction_comparison_report.csv`
