# Public-release notebook audit

## Status

The six notebooks selected for the public FAME repository were audited for
machine-specific paths, embedded outputs, credentials/secrets, and file dependencies.

### Findings

1. **No embedded API keys, passwords, access tokens, or client secrets were detected**
   by the automated source scan.
2. The Energy temporal-replication notebook contained a **machine-specific Windows
   path to the CBC solver/project directory**. The public copy removes that path and
   documents `FAME_CBC_EXE` as the portable solver configuration mechanism.
3. Notebook outputs were cleared in the public copies. This avoids publishing
   machine-specific paths and redundant binary/HTML output; the paper-level numerical
   evidence is retained separately under `results/`.
4. The fantasy-football notebooks require a source file matching
   `cartola_base_modelagem_*.csv`. That raw/analytical source dataset is **not present
   in the curated public package**. The notebooks therefore cannot yet be executed
   end-to-end by an external user without data-acquisition/reconstruction instructions.
5. The Energy temporal-replication notebook requires:
   - `transnetbw_actual_forecast_hourly_utc_2015_2025.csv`;
   - RTS-GMLC `SourceData/gen.csv`;
   - CBC or a compatible configured solver.
   These source files are not currently redistributed in the curated package.
6. The Energy scientific-synthesis notebook expects the directory
   `data/fame_energy_temporal_replication_v34_extended_theta`, whereas the curated
   repository currently stores selected final outputs under `results/energy/`.
   A public release should either adapt the notebook to the curated paths or publish
   the complete minimal input directory expected by the synthesis notebook.
7. The fantasy-football primary/H1/H2 notebooks write their own historical development
   directory names (`resultados_fame_*`). This is acceptable for archival reproduction
   but is not yet aligned with the cleaner public `results/` directory structure.

## Publication recommendation

The repository is **scientifically useful but not yet fully executable from a clean clone**.
Before making it public, complete two tasks:

- document and, where legally permitted, provide the minimum source/processed datasets
  required by the notebooks;
- run every notebook from a fresh clone/environment and freeze exact dependency versions.

The existing `results/` files are already appropriate for audit/review because they expose
the numerical artifacts supporting the manuscript without requiring expensive reruns.


## Repository-path refactor completed

The public notebook copies now:

- discover the repository root instead of assuming a working directory;
- read external inputs only from documented `data/raw/` locations or explicit environment
  variables;
- write fresh outputs to `reproduced/` rather than historical development directories;
- use the same `reproduced/` paths for temporal-comparison and Energy-synthesis notebooks;
- no longer recursively search the user's filesystem for source data;
- no longer contain author-machine absolute paths.

The remaining limitation is external-data availability, not internal path portability.
