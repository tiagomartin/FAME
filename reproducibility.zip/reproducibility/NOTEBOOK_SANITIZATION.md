# Notebook text/comment policy

For the public FAME repository, all notebooks under `code/` were sanitized as follows:

- all Markdown cells removed;
- all raw/text cells removed;
- all Python comment tokens removed, including inline comments;
- code cells that became empty after comment removal deleted;
- notebook outputs cleared;
- execution counts cleared;
- cell metadata stripped;
- Python syntax revalidated after sanitization.

The resulting notebooks contain executable code cells only.

See `notebook_text_comment_audit.csv` for the per-notebook audit.
