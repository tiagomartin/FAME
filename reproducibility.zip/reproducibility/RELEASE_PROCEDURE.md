# GitHub release procedure

For the manuscript-associated public release:

1. Complete the clean-clone rerun.
2. Save `reproducibility/reproduction_comparison_report.csv`.
3. Freeze exact package versions in `requirements.txt` or `environment.yml`.
4. Verify all source-data terms and update `data/SOURCES_AND_RECONSTRUCTION.md`.
5. Update `CITATION.cff` with ORCID identifiers if desired.
6. Commit the final manuscript-associated repository state.
7. Tag the commit as:

```text
v1.0.0
```

8. Create a GitHub release titled:

```text
FAME v1.0.0 — manuscript reproducibility release
```

9. Suggested release description:

> Reproducibility release accompanying the manuscript
> "Temporal Transferability of Prediction-to-Decision Representations in
> Constrained Resource Allocation". This release freezes the code, processed
> experimental artifacts, temporal split definitions, robustness analyses,
> and supplementary materials associated with the reported results.

10. Optionally archive the GitHub release with Zenodo and add the resulting DOI to
    `CITATION.cff` and the manuscript's Code Availability statement.
