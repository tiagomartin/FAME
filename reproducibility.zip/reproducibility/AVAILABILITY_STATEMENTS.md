# Suggested manuscript availability statements

## Data availability

The data supporting the findings of this study are derived from publicly available and
third-party sources. Temporal split definitions, processed experimental artifacts, and the
materials required to audit the reported analyses are publicly available in the FAME GitHub
repository at https://github.com/tiagomartin/FAME. Raw third-party data are not redistributed
where the applicable source terms have not been verified for redistribution. The repository
provides the corresponding source information, expected data structure, and reconstruction
instructions.

## Code availability

The source code used to implement the FAME framework, perform Decision-Oriented Calibration,
execute the temporal evaluation protocols, and reproduce the reported analyses is publicly
available at https://github.com/tiagomartin/FAME. The repository also contains archived
machine-readable artifacts supporting the reported results and a documented workflow for
reproducing the experiments from the required external data sources.
